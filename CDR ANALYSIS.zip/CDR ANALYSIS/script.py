import pandas as pd
import matplotlib.pyplot as plt
import os
import folium

# ================= SETUP =================
if not os.path.exists("static"):
    os.makedirs("static")

# ================= LOAD DATA =================
df = pd.read_csv("cdrrecord.csv", encoding='latin1', on_bad_lines='skip')

# Clean column names (VERY IMPORTANT)
df.columns = df.columns.str.strip()

print("Columns in dataset:", df.columns)

# ================= FIX COLUMN NAMES =================

# Fix Number column
if 'Number' not in df.columns:
    for col in df.columns:
        if 'number' in col.lower():
            df.rename(columns={col: 'Number'}, inplace=True)

# Fix Time column
if 'Time' not in df.columns:
    for col in df.columns:
        if 'time' in col.lower():
            df.rename(columns={col: 'Time'}, inplace=True)

# Fix Date column
if 'Date' not in df.columns:
    for col in df.columns:
        if 'date' in col.lower():
            df.rename(columns={col: 'Date'}, inplace=True)

# Fix Duration column
duration_col = None
for col in df.columns:
    if 'dur' in col.lower():
        duration_col = col
        break

if duration_col:
    df['Duration_sec'] = pd.to_numeric(df[duration_col], errors='coerce').fillna(0)
else:
    print("⚠️ Duration column not found, creating dummy")
    df['Duration_sec'] = 0

# ================= CLEANING =================
if 'Time' in df.columns:
    df['Hour'] = pd.to_datetime(df['Time'], errors='coerce').dt.hour
else:
    df['Hour'] = 0

if 'Date' in df.columns:
    df['Date'] = pd.to_datetime(df['Date'], errors='coerce', dayfirst=True)

# ================= BASIC INFO =================
print("\n=== BASIC INFO ===")
print("Total Calls:", len(df))
print("Total Duration:", df['Duration_sec'].sum())

# ================= TOP CONTACTS =================
if 'Number' in df.columns:
    top_calls = df['Number'].value_counts().head(5)

    print("\n=== TOP CONTACTED NUMBERS ===")
    print(top_calls)

    plt.figure()
    top_calls.plot(kind='bar')
    plt.title("Top Contacted Numbers")
    plt.xlabel("Number")
    plt.ylabel("Call Count")
    plt.tight_layout()
    plt.savefig("static/top_contacts.png")
    plt.close()

# ================= ACTIVE HOURS =================
active_hours = df['Hour'].value_counts().sort_index()

print("\n=== ACTIVE HOURS ===")
print(active_hours)

plt.figure()
active_hours.plot(kind='bar')
plt.title("Active Hours")
plt.xlabel("Hour")
plt.ylabel("Calls")
plt.tight_layout()
plt.savefig("static/active_hours.png")
plt.close()

# ================= DAILY TREND =================
if 'Date' in df.columns:
    daily_calls = df.groupby(df['Date'].dt.day).size()

    print("\n=== DAILY TREND ===")
    print(daily_calls)

    plt.figure()
    daily_calls.plot(kind='line', marker='o')
    plt.title("Daily Call Activity")
    plt.xlabel("Day")
    plt.ylabel("Calls")
    plt.tight_layout()
    plt.savefig("static/daily_trend.png")
    plt.close()

# ================= MAP =================
base_lat = 12.9716
base_lon = 77.5946

def generate_location(i):
    lat = base_lat + (i % 50) * 0.0005
    lon = base_lon + (i % 50) * 0.0005
    return lat, lon

m = folium.Map(location=[base_lat, base_lon], zoom_start=12, tiles='CartoDB positron')

for i, row in df.head(100).iterrows():
    lat, lon = generate_location(i)

    number = row['Number'] if 'Number' in df.columns else "Unknown"

    folium.Marker(
        location=[lat, lon],
        popup=f"Number: {number} | Duration: {row['Duration_sec']}"
    ).add_to(m)

m.save("static/map.html")
print("\nMap saved → static/map.html")

# ================= SUSPICIOUS ANALYSIS =================
print("\n=== SUSPICIOUS ANALYSIS ===")

if 'Number' in df.columns:
    freq = df['Number'].value_counts()

    print("\nHigh Frequency (>15 calls):")
    print(freq[freq > 15])

print("\nLong Calls (>500 sec):")
print(df[df['Duration_sec'] > 500][['Number','Duration_sec']].head())

print("\nLate Night Calls (0–5 hrs):")
print(df[(df['Hour'] >= 0) & (df['Hour'] <= 5)]['Number'].value_counts().head())