from flask import Flask, render_template
import pandas as pd

app = Flask(__name__)

def load_data():
    df = pd.read_csv("cdrrecord.csv", encoding='latin1', on_bad_lines='skip')
    df.columns = df.columns.str.strip()

    if "Duration_sec" not in df.columns:
        for col in df.columns:
            if "dur" in col.lower():
                df["Duration_sec"] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    return df

@app.route("/")
def home():
    df = load_data()

    return render_template(
        "index.html",
        total_calls=len(df),
        total_duration=int(df["Duration_sec"].sum())
    )

if __name__ == "__main__":
    app.run(debug=True)